DROP TABLE clicks;
